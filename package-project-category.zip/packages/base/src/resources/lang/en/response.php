<?php


return [
    'data_retrieved_successfully'=>'Data retrieved successfully',
    'invalid_phone_format'=>'Invalid phone format.',
    'data_updated_successfully'=>'Data updated successfully.',
    'process_failed'=>'Process failed.',
    'data_created_successfully'=>'Data created successfully',
    'The_photo_has_been_uploaded_successfully'=>'The photo has been uploaded successfully.',
    'data_deleted_successfully'=>'Data deleted successfully.',

];
