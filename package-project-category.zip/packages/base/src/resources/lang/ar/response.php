<?php


return [

    'data_retrieved_successfully'=>'تم استرجاع البيانات بنجاح.',
    'invalid_phone_format'=>'صيغه الهاتف غير صحيحه.',
    'data_created_successfully'=>'تم الادراج بنجاح',
    'data_updated_successfully'=>'تم تحديث المعلومات بنجاح',
    'process_failed'=>'فشلت العمليه .',
    'The_photo_has_been_uploaded_successfully'=>'تم رفع الصوره بنجاح .',
    'data_deleted_successfully'=>'تم الحذف بنجاح .',

];
