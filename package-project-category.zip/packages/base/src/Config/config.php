<?php

return [

    /*
     * hasing use SHA256 with key dr.afeef
     */
    'api_token' => env('API_TOKEN' , 'c35fa9a7b7ca4d3318f40ffc3f37269a88c711d705faf46927b4ff39ae3bdecf')

];
