<?php

/*
 * @author Anas almasri (drafeef\base)
 * @Description: This is class for default request
 */

namespace drafeef\base\Constants;


 final class Request {


    public const MAX_LIMIT = 150 ;

    public const MIN_LIMIT = 1 ;

    public const DEFAULT_PAGE = 1;



 }
