<?php

/*
 * @author Anas almasri (anas.almasri@merwas.net)
 * @Description: This is class for get name of the trash folder
 */

namespace drafeef\base\Constants;


final class MediaFolder {

    public const TRASHED_FOLDER = 'trash' ;

}
