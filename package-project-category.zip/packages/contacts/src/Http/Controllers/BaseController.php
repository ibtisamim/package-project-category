<?php

/***************************************************************
 *
 * @Original_Author: anas almasri (anas.almasri@merwas.net)
 * @Description: This Base Controller from base package
 *
 ***************************************************************
 */

namespace drafeef\contacts\Http\Controllers;

use drafeef\base\Http\Controllers\BaseController as Controller;

class BaseController extends Controller {}
