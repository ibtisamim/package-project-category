<?php

/***************************************************************
 *
 * @Original_Author: anas almasri (anas.almasri@merwas.net)
 * @Description: This Base model from base package
 *
 ***************************************************************
 */

namespace drafeef\contacts\Models;

use drafeef\base\Models\BaseModel as Model;

class BaseModel extends Model{}
