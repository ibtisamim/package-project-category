<?php


return [

	'contact_not_found' => 'نموذج الاتصال غير موجود.' ,
	
];
