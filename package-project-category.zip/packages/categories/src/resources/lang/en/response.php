<?php


return [

	'category_not_found' =>'This category not found',
	'category_parent_not_found' =>'This category parent not found',
	'icon_not_found' =>'This icon image not found',
	'languages_not_all_inserted' =>'Please, insert values in all available languages',
	'slug_found' =>'Category slug must be unique',
	'slug_not_found' => 'Slug not found',
	'article_not_found' =>'Article not found',
	'section_not_found' =>'Section not found',
	'level_not_found' =>'Level not found!',
	
];
