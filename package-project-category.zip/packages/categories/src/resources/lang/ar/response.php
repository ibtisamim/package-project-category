<?php


return [

	'category_not_found' =>'هذه الفئة غير موجودة',
	'category_parent_not_found' =>'هذه الفئة الأصل غير موجود',
	'icon_not_found' =>'هذه الصورة الرمزية غير موجودة',
	'languages_not_all_inserted' =>'من فضلك ، أدخل القيم بجميع اللغات المتاحة',
	'slug_found' =>'يجب أن تكون سبيكة الفئة فريدة',
	'slug_not_found' => 'سبيكة غير موجودة',
	'article_not_found' =>'لم يتم العثور على المادة',
	'section_not_found' =>'القسم غير موجود',
	'level_not_found' =>'المستوى غير موجود!',
];
