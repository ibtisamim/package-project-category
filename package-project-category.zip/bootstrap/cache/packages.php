<?php return array (
  'drafeef/app_setting' => 
  array (
    'providers' => 
    array (
      0 => 'drafeef\\app_setting\\providers\\AppServiceProvider',
      1 => 'drafeef\\app_setting\\providers\\EventServiceProvider',
      2 => 'drafeef\\app_setting\\providers\\RouteServiceProvider',
    ),
  ),
  'drafeef/base' => 
  array (
    'providers' => 
    array (
      0 => 'drafeef\\base\\providers\\AppServiceProvider',
      1 => 'drafeef\\base\\providers\\EventServiceProvider',
      2 => 'drafeef\\base\\providers\\RouteServiceProvider',
    ),
  ),
  'drafeef/categories' => 
  array (
    'providers' => 
    array (
      0 => 'drafeef\\categories\\providers\\AppServiceProvider',
      1 => 'drafeef\\categories\\providers\\EventServiceProvider',
      2 => 'drafeef\\categories\\providers\\RouteServiceProvider',
    ),
  ),
  'drafeef/contacts' => 
  array (
    'providers' => 
    array (
      0 => 'drafeef\\contacts\\providers\\AppServiceProvider',
      1 => 'drafeef\\contacts\\providers\\EventServiceProvider',
      2 => 'drafeef\\contacts\\providers\\RouteServiceProvider',
    ),
  ),
  'drafeef/exams' => 
  array (
    'providers' => 
    array (
      0 => 'drafeef\\exams\\providers\\AppServiceProvider',
      1 => 'drafeef\\exams\\providers\\EventServiceProvider',
      2 => 'drafeef\\exams\\providers\\RouteServiceProvider',
    ),
  ),
  'drafeef/notifications' => 
  array (
    'providers' => 
    array (
      0 => 'drafeef\\notifications\\providers\\AppServiceProvider',
      1 => 'drafeef\\notifications\\providers\\EventServiceProvider',
      2 => 'drafeef\\notifications\\providers\\RouteServiceProvider',
    ),
  ),
  'drafeef/places' => 
  array (
    'providers' => 
    array (
      0 => 'drafeef\\places\\providers\\AppServiceProvider',
      1 => 'drafeef\\places\\providers\\EventServiceProvider',
      2 => 'drafeef\\places\\providers\\RouteServiceProvider',
    ),
  ),
  'drafeef/users' => 
  array (
    'providers' => 
    array (
      0 => 'drafeef\\users\\providers\\AppServiceProvider',
      1 => 'drafeef\\users\\providers\\EventServiceProvider',
      2 => 'drafeef\\users\\providers\\RouteServiceProvider',
    ),
  ),
  'kreait/laravel-firebase' => 
  array (
    'providers' => 
    array (
      0 => 'Kreait\\Laravel\\Firebase\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Firebase' => 'Kreait\\Laravel\\Firebase\\Facades\\Firebase',
    ),
  ),
  'laravel/passport' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Passport\\PassportServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'spatie/laravel-activitylog' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Activitylog\\ActivitylogServiceProvider',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'spatie/laravel-translatable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Translatable\\TranslatableServiceProvider',
    ),
  ),
);